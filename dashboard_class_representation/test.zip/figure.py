"""
Draws interactive ridge plot for key run distribution.

    Example use:

    ridgeplot = figure.RidgePlot(data)
    fig = ridgeplot.figure

Data is a pandas df formatted as:
    columns are [key level]s
    rows are [spec]s
    cells are number of runs at [key level] for [spec]
"""

import importlib
from typing import List, Tuple, Type  # you have to import Type

import pandas as pd
import plotly.graph_objects as go

import blizzcolors


class RidgePlot:
    """Draws the ridge plot."""

    def __init__(self, data):
        """Inits with the formatted pandas dataframe.

        Params
        ------
        data : DataFrame
            spec should be the row, and level of key the columns
        """
        self.data = data  # the table should already be pivoted
        self.summary = self._get_summary_table(data)
        sorted_summary = self._sort_summary(sort_by="best_key")

        self.traces = self._construct_traces(sorted_summary)
        self.annotations = self._construct_annotations(sorted_summary)
        self.buttons = self._construct_buttons()
        self.figure = self._assemble_components()

    def _get_summary_table(self, data):
        """Computes total population and best key for each spec."""
        summary = pd.DataFrame(data.index)
        summary["total_run"] = data.sum(axis=1).values
        summary["best_key"] = data.apply(
            lambda x: self._find_highest_key(x), axis=1
        ).values
        return summary

    @staticmethod
    def _find_highest_key(row):
        """Finds index of the last non-zero int in list."""
        highest_key_index = None
        for bin_, num_keys_in_bin in enumerate(row):
            if num_keys_in_bin != 0:
                highest_key_index = bin_
        highest_key_level = highest_key_index + 2  # key level starts with 2
        return highest_key_level

    def _sort_summary(self, sort_by="best_key"):
        """Sorts summary by the given column."""
        if sort_by not in ["best_key", "total_run"]:
            raise ValueError(
                (
                    "Data can be sorted either by best_key"
                    "or by total_run number of runs"
                )
            )
        sort_order = ["best_key", "total_run"]
        if sort_by == "total_run":
            sort_order = sort_order[::-1]
        sorted_summary = self.summary.sort_values(by=sort_order, ascending=False)
        return sorted_summary

    def _construct_traces(self, sorted_summary):
        """Makes line/fill traces of the data distribution."""
        key_levels = list(self.data)
        key_levels_x = [i - 2 for i in list(key_levels)]  # x =0, key - 2
        vertical_offset = 300_000
        num_specs = len(self.summary)
        specs = blizzcolors.Specs()
        traces = {}
        for index, row in enumerate(list(sorted_summary.values)):
            spec_id = row[0]
            spec_color = "rgba(%d,%d,%d,0.9)" % specs.get_color(spec_id)
            runs = self.data.loc[self.data.index == spec_id].values[0]
            # horizontal baseline for each ridge distribution
            baseline_y = vertical_offset * (num_specs - index)
            baseline = go.Scatter(
                x=key_levels_x,
                y=[baseline_y] * len(key_levels_x),
                line=dict(width=0.5, color="black"),
                hoverinfo="skip",
            )
            # the distribution of runs vs key level (the star of the show)
            ridge = go.Scatter(
                x=key_levels_x,
                y=[baseline_y + run for run in runs],
                fill="tozerox",
                fillcolor=spec_color,
                line=dict(width=1, color="black", shape="spline"),
                name=specs.get_spec_name(spec_id).upper(),
                text=[f"{y:,}" for y in runs],
                customdata=[i + 2 for i in key_levels_x],
                hovertemplate="KEY LEVEL: +%{customdata}<br>RUNS: %{text}",
            )
            traces[spec_id] = {"ridge": ridge, "baseline": baseline}
        return traces

    def _get_ridge_recolor_pattern(self, keep_role):
        """Generates color list that informs recolor of the traces.

        Given a spec role, recolors all traces not of that role to gray.

        Parameters
        ----------
        keep_role : str
            spec role ('tank', 'healer', 'mdps', 'rdps')

        Returns
        -------
        recolor : list
            list of colors, where color at index i corresponds to trace at
            index i in fig.data
        """
        valid_roles = ["tank", "healer", "mdps", "rdps"]
        keep_role = keep_role.lower()
        if keep_role not in valid_roles:
            raise ValueError("Spec role invalid. Must be one of: %s")
        recolor = []
        specs = blizzcolors.Specs()
        custom_gray = "rgba(0,0,0,0.3)"
        for spec_id, spec_traces in self.traces.items():
            spec_role = specs.get_role(spec_id)
            # reassign color based on spec role
            new_ridge_color = None
            if spec_role == keep_role:
                new_ridge_color = spec_traces["ridge"].fillcolor
            else:
                new_ridge_color = custom_gray
            # keep baseline the original color
            baseline_color = spec_traces["baseline"].line.color
            recolor.append(new_ridge_color)
            recolor.append(baseline_color)
        return recolor

    def _get_all_traces(self):
        """Extracts raw trace objects from trace dict."""
        trace_list = []
        for traces in self.traces.values():
            trace_list.append(traces["ridge"])
            trace_list.append(traces["baseline"])
        return trace_list

    def _construct_annotations(self, sorted_summary):
        """Constructs annotations."""
        annotations = {}
        # spec name placed left of its ridge plot
        annotations["spec_name"] = self._make_spec_name_annos(sorted_summary)
        # best key completed by spec text, placed on top of the ridge plot
        annotations["spec_best_key"] = self._make_spec_best_key_annos(sorted_summary)
        # annotation next to the button row, the label
        annotations["button_label"] = self._make_role_selector_button_text_label()
        # legend element that says "BEST KEY"
        annotations["legend_best_key"] = self._make_best_key_pointer_anno()

        return annotations

    def _make_spec_name_annos(self, sorted_summary):
        """Make spec name annotations."""
        annotations = {}
        vertical_offset = 300_000
        num_specs = len(sorted_summary)
        specs = blizzcolors.Specs()
        for index, row in enumerate(list(sorted_summary.values)):
            spec_id = row[0]
            spec_name = specs.get_spec_name(spec_id).upper()
            baseline_y = vertical_offset * (num_specs - index)
            anno = self._make_spec_name_annotation(
                position_x=0, position_y=baseline_y, text=spec_name
            )
            annotations[spec_id] = anno
        return annotations

    @staticmethod
    def _make_spec_name_annotation(position_x, position_y, text):
        """Creates spec name annotation at position (x, y)."""
        annotation = dict(
            x=position_x,
            y=position_y,
            text=text,
            font=dict(color="black", size=15, family="Monaco, regular"),
            showarrow=False,
            xanchor="right",
            yanchor="bottom",
            borderpad=0,
        )
        return annotation

    def _make_spec_best_key_annos(self, sorted_summary):
        """Make best key annotations for each spec."""
        annotations = {}
        vertical_offset = 300_000
        num_specs = len(sorted_summary)
        for index, row in enumerate(list(sorted_summary.values)):
            spec_id, _, best_key_level = row
            baseline_y = vertical_offset * (num_specs - index)
            anno = self._make_spec_best_key_annotation(
                position_x=best_key_level - 2,
                position_y=baseline_y,
                text="+%d " % best_key_level,
            )
            annotations[spec_id] = anno
        return annotations

    @staticmethod
    def _make_spec_best_key_annotation(position_x, position_y, text):
        """Creates text annotation of each spec's best key."""
        annotation = dict(
            x=position_x,
            y=position_y,
            text=text,
            font=dict(color="black", size=15, family="Monaco, regular"),
            align="center",
            showarrow=True,
            ax=0,
            ay=-15,
            arrowsize=2,
            arrowwidth=1,
            arrowhead=6,
            arrowcolor="gray",
        )
        return annotation

    @staticmethod
    def _make_best_key_pointer_anno():
        """Makes BEST KEY label + arrow that points to the best key."""
        annotation = dict(
            x=29,
            y=11_300_000,
            align="center",
            showarrow=True,
            ax=0,
            ay=-20,
            arrowsize=2,
            arrowwidth=1,
            arrowhead=6,
            # arrowcolor = 'rgba(0,0,0,0.75)'
            arrowcolor="gray",
            text="BEST<br>KEY",
        )
        return annotation

    def _keep_annotations(self, keep_role):
        """Returns annotation list based on spec role."""
        # these are then assigned to specific role-selector buttons
        keep_role = keep_role.lower()
        keep_annotations = []
        always_keep = [
            self.annotations["button_label"],
            self.annotations["legend_best_key"],
        ]
        keep_annotations.extend(always_keep)
        if keep_role == "all":
            keep_annotations.extend(self.annotations["spec_best_key"].values())
            keep_annotations.extend(self.annotations["spec_name"].values())
        else:
            names = self._sort_annos_by_spec(self.annotations["spec_name"], keep_role)
            best_keys = self._sort_annos_by_spec(
                self.annotations["spec_best_key"], keep_role
            )
            keep_annotations.extend(names)
            keep_annotations.extend(best_keys)
        return keep_annotations

    @staticmethod
    def _sort_annos_by_spec(annotations, keep_role):
        """Given a dictionary of annotations, return those that match role."""
        valid_roles = ["tank", "healer", "mdps", "rdps"]
        specs = blizzcolors.Specs()
        if keep_role not in valid_roles:
            raise ValueError("Spec role invalid. Must be one of: %s")
        keep_annotations = []
        for spec_id, annotation in annotations.items():
            spec_role = specs.get_role(spec_id)
            if spec_role == keep_role:
                keep_annotations.append(annotation)
        return keep_annotations

    def _construct_buttons(self):
        """Creates buttons that change colors and annos based on spec role."""
        role_selector = self._make_role_selector_buttons()
        # clear_button = self.make_annotation_button()
        # return [role_selector, clear_button]
        return [role_selector]

    def _make_clear_button(self):
        """Creates buttoni that clears best key annotations."""
        anno_display = dict(
            type="buttons",
            xanchor="right",
            x=1,
            y=1.05,
            buttons=[
                dict(
                    args=[{"annotations": self._keep_annotations("all")}],
                    label="CLEAR BEST KEY",
                    method="relayout",
                )
            ],
            showactive=False,
        )
        return anno_display

    def _make_role_selector_buttons(self):
        """Creates row of bottons that recolor plot based on spec role."""
        default_colors = self._get_default_colors()
        buttons = [
            dict(
                args=[
                    {"fillcolor": default_colors},
                    {"annotations": self._keep_annotations("all")},
                ],
                label="ALL",
                method="update",
            ),
            dict(
                args=[
                    {"fillcolor": self._get_ridge_recolor_pattern("tank")},
                    {"annotations": self._keep_annotations("tank")},
                ],
                label="TANK",
                method="update",
            ),
            dict(
                args=[
                    {"fillcolor": self._get_ridge_recolor_pattern("healer")},
                    {"annotations": self._keep_annotations("healer")},
                ],
                label="HEALER",
                method="update",
            ),
            dict(
                args=[
                    {"fillcolor": self._get_ridge_recolor_pattern("mdps")},
                    {"annotations": self._keep_annotations("mdps")},
                ],
                label="MELEE",
                method="update",
            ),
            dict(
                args=[
                    {"fillcolor": self._get_ridge_recolor_pattern("rdps")},
                    {"annotations": self._keep_annotations("rdps")},
                ],
                label="RANGE",
                method="update",
            ),
        ]
        role_selector = dict(
            type="buttons",
            direction="left",
            xanchor="left",
            x=0.07,
            y=1.05,
            buttons=buttons,
        )
        return role_selector

    @staticmethod
    def _make_role_selector_button_text_label():
        """Creates a text label for the botton row."""
        annotation = dict(
            x=0, y=1.045, xref="paper", yref="paper", text="SPECS:", showarrow=False
        )
        return annotation

    def _get_default_colors(self):
        """Extracts colors from traces."""
        default_colors = []
        for spec_traces in self.traces.values():
            default_colors.append(spec_traces["ridge"].fillcolor)
            default_colors.append(spec_traces["baseline"].line.color)
        return default_colors

    def _get_all_annotations(self):
        """Returns all annotations that figure shows by default."""
        return self.annotations.values()

    def _assemble_components(self) -> Type[go.Figure]:
        """Assembles traces, annotations, and buttons into a plotly figure."""
        fig = go.Figure(data=self._get_all_traces())
        fig.update_layout(width=900, height=1500, showlegend=False)
        fig.update_layout(updatemenus=self.buttons)
        fig.update_layout(annotations=self._keep_annotations("all"))

        xaxis = dict(
            title="<b>KEY LEVEL</b>",
            range=[-6, 30],
            tickvals=[0] + list(range(3, 30, 5)),
            ticktext=["+2"] + ["+" + str(i + 2) for i in range(3, 30, 5)],
        )

        xaxis2 = dict(
            range=[-6, 30],
            tickvals=[0] + list(range(3, 30, 5)),
            ticktext=["+2"] + ["+" + str(i + 2) for i in range(3, 30, 5)],
            side="top",
            overlaying="x",
        )

        yaxis = go.layout.YAxis(range=[0, 12_300_000], tickvals=[])
        fig.update_layout(yaxis=yaxis)
        fig.update_layout(xaxis=xaxis, xaxis2=xaxis2)
        # this is a stupid hack... The second axis won't show up unless
        # there is a trace associated with it. So associate this dummy trace
        # with the secondary axis. The trace is invisible.
        fig.add_trace(go.Scatter(x=[1], y=[1], xaxis="x2", visible=False))
        return fig


class StackedAreaPlot:
    """Docstring."""

    def __init__(self, data, chart_type, spec_role):
        """Inits with pivoted table of specs vs key levels."""
        self.chart_type = chart_type
        self.data = data
        if self.chart_type == "week":
            self.data.columns = self.data.columns - min(self.data.columns) + 1
        self.specs = blizzcolors.Specs()
        self.traces = self._construct_components(spec_role)
        self.layout = self._define_layout()
        self.hovertemplate = None

    def set_hovertemplate(self, hovertemplate: dict):
        """Sets hovertemplate var of the trace objects."""
        self.hovertemplate = hovertemplate

    def get_xaxis(self) -> dict:
        """Creates plotly xaxis for the figure."""
        xaxis = dict()
        min_xrange = min(list(self.data))
        max_xrange = max(list(self.data))
        if self.chart_type == "key":
            tickvals = list(range(0, max_xrange + 1, 5))
            tickvals[0] = 2
            xaxis = dict(
                title="<b>KEY LEVEL</b>",
                range=[min_xrange, max_xrange],
                tickvals=tickvals,
                ticktext=["+" + str(tv) for tv in tickvals],
            )
        elif self.chart_type == "week":
            if max_xrange > 11:
                tickvals = list(range(0, max_xrange + 1, 4))
                tickvals[0] = 1
            else:
                tickvals = list(range(min_xrange, max_xrange + 1, 1))
            xaxis = dict(
                title="<b>WEEK</b>",
                range=[min_xrange, max_xrange],
                tickvals=tickvals,
                ticktext=[str(tv - min_xrange + 1) for tv in tickvals],
            )
        return xaxis

    def _construct_components(self, spec_role):
        """Constructs figure components."""
        valid_roles = ["tank", "healer", "mdps", "rdps"]
        spec_role = spec_role.lower()
        if spec_role not in valid_roles:
            raise ValueError("Spec role invalid. Must be one of: %s")
        spec_ids = self.specs.get_spec_ids_for_role(spec_role)
        traces = self._make_trace(spec_ids)
        return traces

    def assemble_figure(self):
        """Assemble plotly figure from pre-made components."""
        fig = go.Figure(data=self.traces)
        fig.update_layout(self.layout)
        return fig

    def _define_layout(self):
        """Define layout of the plotly figure."""
        layout = dict(
            width=900, height=500, xaxis=self.get_xaxis(), yaxis=get_yaxis_pct_share()
        )
        return layout

    def _make_trace(self, spec_ids):
        """Crates a trace dict for a spec."""

        traces = []
        for spec_id in spec_ids:
            key_level = list(self.data)
            spec_share = list(self.data.loc[self.data.index == spec_id, :].values[0])
            spec_color = "rgba(%d,%d,%d,0.7)" % self.specs.get_color(spec_id)
            spec_trace = self._make_tracex(
                key_level,
                spec_share,
                fillcolor=spec_color,
                name=self.specs.get_spec_name(spec_id).upper(),
            )
            traces.append(spec_trace)
        return traces

    def _make_tracex(self, key_level, spec_share, fillcolor, name):
        """Make trace dict for line."""
        if self.chart_type == "key":
            hovertemplate = "KEY LEVEL: +%{x:d}<br> SHARE: %{y:.0f}%"
        elif self.chart_type == "week":
            hovertemplate = "WEEK: %{x}<br> SHARE: %{y:.0f}%"
        trace = go.Scatter(
            x=key_level,
            y=spec_share,
            mode="lines",
            line=dict(width=1.5, color="black"),
            hoveron="points",
            hovertext="test",
            hovertemplate=hovertemplate,
            fillcolor=fillcolor,
            stackgroup="one",
            groupnorm="percent",
            name=name,
        )
        return trace


def get_yaxis_pct_share() -> dict:
    """Sets yaxis properties of a %normalized share-of-total figure."""
    ytickvals = [0, 20, 40, 60, 80, 100]
    yaxis = dict(
        title="<b>SHARE OF TOTAL (%)</b>",
        range=[0, 101],
        tickvals=ytickvals,
        ticktext=[str(val) + "%" for val in ytickvals],
    )
    return yaxis


def find_keys_xaxis_range(data: pd.DataFrame) -> Tuple[int, int]:
    """Calculates appropriate axes ranges for figure."""
    # Ridge figure sizing is very finicky, so I define ranges by hand based on
    # max key level. I have tested these by hand and know that they look OK.
    min_key_level = 2
    max_key_level = max(list(data)) + 1
    xrange_ = (min_key_level, max_key_level)
    return xrange_
